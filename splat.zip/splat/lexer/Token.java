package splat.lexer;

public class Token {
    
    //Fields
    private String value;
    private int line;
    private int column;
    
    //Constructor
    public Token(String value, int line, int column){
        
        this.value = value;
        this.line = line;
        this.column = column;
    }
    
    /**
     *
     * @return
     */
    @Override
    public String toString(){
        return "Value: " + getValue() + " Line: " + getLine() + " Column: " + getColumn();
    }

    /**
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * @return the line
     */
    public int getLine() {
        return line;
    }

    /**
     * @return the column
     */
    public int getColumn() {
        return column;
    }   
}
