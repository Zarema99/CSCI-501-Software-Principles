package splat.lexer;

import java.io.File;
import java.util.List;
import java.util.*;
import java.io.*;


public class Lexer {
    
    //Fields
    private File infile;

    //Constructor
    public Lexer(File progFile) {
	// TODO Auto-generated constructor stub
        infile = progFile;
    }

    public List<Token> tokenize() throws LexException {
	// TODO Auto-generated method stub
        
        List<Token> tokenList = new LinkedList<Token>();       
        BufferedReader reader;
         
        //catch FileNotFoundException
        try {
            reader = new BufferedReader(new FileReader(infile));
        } catch (FileNotFoundException ex) {
            throw new LexException("FileNotFoundException!!!", -1,-1);
        }
        
        int ch, firstChar, line = 1, col = 1, start_col = 1, start_col_prev = 1, line_quote = 0, start_col_quote = 0;
        boolean quote = false, symbol2 = false;          
        String token = "";
        
        //Symbols used in SPLAT grammar
        //ASCII of 0-9: 48-57
        //ASCII of A-Z: 65-90
        //ASCII of a-z: 97-122
        // '"', '_'
        List<String> oneSymbolToken = Arrays.asList(";", "(", ")", ",", "+", "-", "*", "/", "%");   
        List<String> oneOrTwoSymbolToken = Arrays.asList(":", ">", "<", "="); 
        List<String> separatorToken = Arrays.asList(" ", "\n", "\t", "\r", "" + (char)(-1));  
         
        do{
            //catch IOException
            try {
                ch = reader.read();
            } catch (IOException ex) {
                throw new LexException("IOException!!!", -1,-1);
            }
            
            //check if ch is in SPLAT grammar
            boolean contains_symbol1 = oneSymbolToken.contains("" + (char)ch);
            boolean contains_symbol2 = oneOrTwoSymbolToken.contains("" + (char)ch);
            boolean contains_separator = separatorToken.contains("" + (char)ch);
            
            //update line and column when there is a new line
            if (ch == '\n'){
                line++;
                col = 1;
                start_col_prev = start_col;
                start_col = 1;
            }
            
            if (quote == true){
                
                if (ch == '"'){     //string is finished                  
                    token = token + (char)ch;
                    Token tokenToList = new Token(token, line, start_col);
                    tokenList.add(tokenToList);
                    token = "";
                    col++;
                    start_col = col;
                    quote = false;

                }else if (ch == '\n' || ch == '\r' || ch == '\t'){    //Error
                    throw new LexException("There should not be escape characters after quote! Error at line " + line + ", column " + start_col,
                            line, start_col);
                }else{
                    token = token + (char)ch;
                    col++;
                }
                    
            }else if (symbol2 == true){     //token can contain a single character or two characters     
                
                if (ch == '='){     //two-character token      
                    token = token + (char)ch;
                    Token tokenToList = new Token(token, line, start_col);
                    tokenList.add(tokenToList);
                    token = "";
                    col++;
                    start_col = col;
                   
                }else{
                    
                    if (token.equals("=")){     //Error
                        throw new LexException(token + " is not in SPLAT grammar! Error at line " + line + ", column " + start_col,
                                line, start_col);
                    }
                 
                    Token tokenToList = new Token(token, line, start_col);                 
                    tokenList.add(tokenToList);
                    
                    if (contains_separator == true){
                        token = ""; 
                        
                        if (ch == '\n'){
                            continue;
                        }
                        col++;
                        start_col = col;                     
                    }else{                           
                        token = "" + (char)ch;
                        start_col = col;
                        col++;
                    }
                }
                symbol2 = false;
                
            }else if (contains_symbol1 == true || contains_symbol2 == true || contains_separator == true ||
                    (ch>=48 & ch<=57) || (ch>=65 & ch<=90) || (ch>=97 & ch<=122) || ch == '"' || ch == '_'){    //all allowed symbols

                if (contains_separator == true){

                    if(token.length() > 0){  
                        
                        if (ch == '\n'){    //line and start_col were updated -> use line-1 and start_col_prev
                            Token tokenToList = new Token(token, line-1, start_col_prev);
                            tokenList.add(tokenToList);
                            token = ""; 
                            
                        }else{

                        Token tokenToList = new Token(token, line, start_col);
                        tokenList.add(tokenToList);
                        token = ""; 
                        col++;
                        start_col = col;
                        }
                              
                    }else{
                        if (ch == ' ' || ch == '\t'){
                            col++;
                            start_col = col;
                        }
                    }

                }else if (ch == '"'){   //start of a potential string

                    if(token.length() > 0){
                        Token tokenToList = new Token(token, line, start_col);
                        tokenList.add(tokenToList);
                        token = "";
                    }
                    
                    quote = true;
                    token = token + (char)ch;         
                    start_col = col;
                    col++;               
                    line_quote = line;
                    start_col_quote = start_col;

                }else if(contains_symbol1 == true){     //single symbol token
                    
                    if(token.length() > 0){                     
                        Token tokenToList = new Token(token, line, start_col);
                        tokenList.add(tokenToList);
                    }
                         
                    token = "" + (char)ch;
                    start_col = col;
                            
                    Token tokenToList = new Token(token, line, start_col);          
                    tokenList.add(tokenToList);           
                    token = "";
                    col++;
                    start_col = col;
                            
                }else if (contains_symbol2 == true){    //token can contain single character or two characters
                    
                    if(token.length() > 0){             
                        Token tokenToList = new Token(token, line, start_col);
                        tokenList.add(tokenToList);
                        token = "";
                    }

                    symbol2 = true;
                    token = token + (char)ch;
                    start_col = col;
                    col++;       
                }
                    
                else{
                    token = token + (char)ch;
                    col++;
                }

            }else{      //symbols not allowed in SPLAT grammar -> Error
                
                throw new LexException("" + (char)ch + " is not in SPLAT grammar! Error at line " + line + ", column " + col,
                        line, col);
            }
            
            
            if (token.length() > 0){     
                
                firstChar = token.charAt(0);                             
              
                if ((firstChar >= 48 & firstChar <= 57) & (ch >= 65 & ch <=122)){   //Error        
                    throw new LexException("Variable name cannot start with a digit! Error at line " + line + ", column " + start_col,
                            line, start_col);
                }
            }
            
            if (ch == -1 & quote == true){      //Error
                throw new LexException("There should be two quotes! Error at line " + line_quote + ", column " + start_col_quote, 
                        line_quote, start_col_quote);
            }
            
            
        }while(ch != -1);     

        return tokenList;
    }
}
