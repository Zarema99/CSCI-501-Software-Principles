package splat.executor;

public abstract class Value {

	// TODO: Implement me!  

    /**
     *
     * @return
     */
    
        @Override
        public abstract String toString();
}
