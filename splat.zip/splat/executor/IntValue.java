package splat.executor;

public class IntValue extends Value{
    
    private int val;
    
    public IntValue(int val) {		
            this.val = val;
    }
    
    /**
     *
     * @return
     */
    @Override
    public String toString() {                          
            String result = Integer.toString(getVal());               
            return result;
    }

    /**
     * @return the val
     */
    public int getVal() {
        return val;
    }  
}
