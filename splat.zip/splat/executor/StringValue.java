package splat.executor;

public class StringValue extends Value{
    
    private String val;
    
     public StringValue(String val) {		
            this.val = val;
    }
     
    /**
     *
     * @return
     */
    @Override
    public String toString() {                          
            String result = getVal();              
            return result;
    }

    /**
     * @return the val
     */
    public String getVal() {
        return val;
    }  
}
