package splat.executor;

public class BoolValue extends Value{
    
    private boolean val;
    
    public BoolValue(boolean val) {		
            this.val = val;
    }

    /**
     *
     * @return
     */
    @Override
    public String toString() {                          
            String result = Boolean.toString(isVal());               
            return result;
    }
    
    /**
     * @return the val
     */
    public boolean isVal() {
        return val;
    }   
}
