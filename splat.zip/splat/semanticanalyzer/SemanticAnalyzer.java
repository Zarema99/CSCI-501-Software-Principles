package splat.semanticanalyzer;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.HashMap;
import java.util.List;

import splat.parser.elements.Declaration;
import splat.parser.elements.FunctionDecl;
import splat.parser.elements.IfThenElse;
import splat.parser.elements.ProgramAST;
import splat.parser.elements.Statement;
import splat.parser.elements.Type;
import splat.parser.elements.VariableDecl;
import splat.parser.elements.Parameter;
import splat.parser.elements.Return;
import splat.parser.elements.ReturnSmth;

public class SemanticAnalyzer {

	private ProgramAST progAST;
	
	private Map<String, FunctionDecl> funcMap = new HashMap<String, FunctionDecl>();
	private Map<String, Type> progVarMap = new HashMap<String, Type>();
        
	
	public SemanticAnalyzer(ProgramAST progAST) {
		this.progAST = progAST;
	}

	public void analyze() throws SemanticAnalysisException {
		
		// Checks to make sure we don't use the same labels more than once
		// for our program functions and variables 
		checkNoDuplicateProgLabels();
		
		// This sets the maps that will be needed later when we need to
		// typecheck variable references and function calls in the 
		// program body
		setProgVarAndFuncMaps();
		
		// Perform semantic analysis on the functions
		for (FunctionDecl funcDecl : funcMap.values()) {	
			analyzeFuncDecl(funcDecl);
		}
		
		// Perform semantic analysis on the program body
		for (Statement stmt : progAST.getStmts()) {
			stmt.analyze(funcMap, progVarMap);
                       
		}
		
	}

	private void analyzeFuncDecl(FunctionDecl funcDecl) throws SemanticAnalysisException {
		
		// Checks to make sure we don't use the same labels more than once
		// among our function parameters, local variables, and function names
		checkNoDuplicateFuncLabels(funcDecl);
		
		// Get the types of the parameters and local variables
		Map<String, Type> varAndParamMap = getVarAndParamMap(funcDecl);
		
		// Perform semantic analysis on the function body
		
                if(!funcDecl.getRet_type().toString().equals("void")){    //NV function
                                       
                    Type type = (Type)funcDecl.getRet_type();  
                    //Special label - to find it later                    
                    varAndParamMap.put("0result", type);
                
                    for (Statement stmt : funcDecl.getStmts()) {
                        
                            if (stmt instanceof Return){
                                throw new SemanticAnalysisException("NV function '" + funcDecl.getLabel().getStr() + "' cannot have return ;", stmt);
                            }
                            
                            stmt.analyze(funcMap, varAndParamMap);
                            
                    }
                    
                    if (!isReturnTm(funcDecl.getStmts())){
                        throw new SemanticAnalysisException("NV function '" + funcDecl.getLabel().getStr() + "' should be return-terminated!", funcDecl.getStmts().get(funcDecl.getStmts().size() - 1));
                    }
                    
                }else{    //void function
                    
                    for (Statement stmt : funcDecl.getStmts()) {
                        
                            if (stmt instanceof ReturnSmth){
                                throw new SemanticAnalysisException("Void function '" + funcDecl.getLabel().getStr() + "' cannot have return <expr> ;", stmt);
                            }
                            
                            stmt.analyze(funcMap, varAndParamMap);                        
                    }
                }
	}
	
	
	private Map<String, Type> getVarAndParamMap(FunctionDecl funcDecl) {
		
		// FIXME: Somewhat similar to setProgVarAndFuncMaps()
                
                Map<String, Type> varAndParamMap = new HashMap<String, Type>();
                                
                //Parameters to the map
                for (Parameter param : funcDecl.getParams()) {

			String label = param.getLabel().toString();   
                        varAndParamMap.put(label, param.getType());		
		}
               
                //Local variables to the map
                for (VariableDecl loc_var_decl : funcDecl.getLoc_var_decls()) {

			String label = loc_var_decl.getLabel().toString();        
                        varAndParamMap.put(label, loc_var_decl.getType());	
		}
             
		return varAndParamMap;
	}

	private void checkNoDuplicateFuncLabels(FunctionDecl funcDecl) 
									throws SemanticAnalysisException {
		
		// FIXME: Similar to checkNoDuplicateProgLabels()
                
                Set<String> labels = new HashSet<String>();
                
                //Check parameters
                for (Parameter param : funcDecl.getParams()) {
                    
 			String label = param.getLabel().toString();
 			
			if (labels.contains(label)) {
				throw new SemanticAnalysisException("Cannot have duplicate label '"
						+ label + "' in parameters of a function", param);
                                
			}else if (funcMap.containsKey(label)){
                                throw new SemanticAnalysisException("Cannot have duplicate label of a function '"
						+ label + "' in parameters of a function", param);
                        } 
                        
                        else {
				labels.add(label);
			}	
		}
                
                //Check local variables
                for (VariableDecl loc_var_decl : funcDecl.getLoc_var_decls()) {
                    
 			String label = loc_var_decl.getLabel().toString();
 			
			if (labels.contains(label)) {
				throw new SemanticAnalysisException("Cannot have duplicate label '"
						+ label + "' in local variables of a function", loc_var_decl);
                                
			}else if (funcMap.containsKey(label)){
                                throw new SemanticAnalysisException("Cannot have duplicate label of a function '"
						+ label + "' in local variables of a function", loc_var_decl);
                        } 
                        
                        else {
				labels.add(label);
			}	
		}        
	}
	
	private void checkNoDuplicateProgLabels() throws SemanticAnalysisException {
		
		Set<String> labels = new HashSet<String>();
		
 		for (Declaration decl : progAST.getDecls()) {
 			String label = decl.getLabel().toString();
 			
			if (labels.contains(label)) {
				throw new SemanticAnalysisException("Cannot have duplicate label '"
						+ label + "' in program", decl);
			} else {
				labels.add(label);
			}	
		}
                
                
	}
	
	private void setProgVarAndFuncMaps() {
		
		for (Declaration decl : progAST.getDecls()) {

			String label = decl.getLabel().toString();
			
			if (decl instanceof FunctionDecl) {
				FunctionDecl funcDecl = (FunctionDecl)decl;
				funcMap.put(label, funcDecl);
				
			} else if (decl instanceof VariableDecl) {
				VariableDecl varDecl = (VariableDecl)decl;
				progVarMap.put(label, varDecl.getType());
			}
		}
	}
        
        //Function that checks whether NV function is return-terminated
        private boolean isReturnTm(List<Statement> stmts){
            
            //last statement
            Statement stmt = stmts.get(stmts.size() - 1);
            
            if (stmt instanceof ReturnSmth){
                return true;
                
            }else if (stmt instanceof IfThenElse){
                
                IfThenElse ifElseStmt = (IfThenElse)stmt;
                return isReturnTm(ifElseStmt.getStmts1()) && isReturnTm(ifElseStmt.getStmts2()); 
            }
            
           return false; 
        }
}
