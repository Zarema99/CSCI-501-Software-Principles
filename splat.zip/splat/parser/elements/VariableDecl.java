package splat.parser.elements;

import splat.lexer.Token;

public class VariableDecl extends Declaration {

	// Need to add some fields
        private Type type;
	
	// Need to add extra arguments for setting fields in the constructor 
	public VariableDecl(Label label, Type type, Token tok) {
		super(label, tok);
                this.type = type;
	}

	// Fix this as well

    /**
     *
     * @return
     */
        @Override
	public String toString() {
                String result = super.label + " : " + type + " ;";
                return result;
	}

        // Getters?
        /**
         * @return the type
         */
        public Type getType() {
            return type;
        }
}
