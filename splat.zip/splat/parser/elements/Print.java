package splat.parser.elements;

import java.util.Map;
import splat.executor.ExecutionException;
import splat.executor.ReturnFromCall;
import splat.executor.Value;
import splat.lexer.Token;
import splat.semanticanalyzer.SemanticAnalysisException;

public class Print extends Statement{
    
        //Fields
        private Expression expr;
    
        public Print(Expression expr, Token tok) {
		super(tok);
                this.expr = expr;
	}
        
    /**
     *
     * @return
     */
    @Override
        public String toString() {
                
                String result = "print " + expr  + " ;"; 
                return result;
	}
        
        /**
         * @return the expr
         */
        public Expression getExpr() {
            return expr;
        }

        @Override
        public void analyze(Map<String, FunctionDecl> funcMap, Map<String, Type> varAndParamMap) throws SemanticAnalysisException {            
            Type expr_type = expr.analyzeAndGetType(funcMap, varAndParamMap);
        }

        @Override
        public void execute(Map<String, FunctionDecl> funcMap, Map<String, Value> varAndParamMap) throws ReturnFromCall, ExecutionException {            
            Value expr_val = expr.evaluate(funcMap, varAndParamMap);
            System.out.print(expr_val);
        }   
}
