package splat.parser.elements;

import java.util.Map;
import splat.executor.ExecutionException;
import splat.executor.ReturnFromCall;
import splat.executor.Value;
import splat.lexer.Token;
import splat.semanticanalyzer.SemanticAnalysisException;

public class ReturnSmth extends Statement{
    
        //Fields
        private Expression expr;
    
        public ReturnSmth(Expression expr, Token tok) {
		super(tok);
                this.expr = expr;
	}
        
    /**
     *
     * @return
     */
    @Override
        public String toString() {
                String result = "return " + expr + " ;";
                return result;
	}

        /**
         * @return the expr
         */
        public Expression getExpr() {
            return expr;
        }

        @Override
        public void analyze(Map<String, FunctionDecl> funcMap, Map<String, Type> varAndParamMap) throws SemanticAnalysisException {           
            Type expr_type = expr.analyzeAndGetType(funcMap, varAndParamMap);

            if (funcMap.isEmpty()){
                throw new SemanticAnalysisException("Cannot have return<expr> in main program;", expr);
            }

            if(varAndParamMap.containsKey("0result")){
                
                if (!expr_type.getStr().equals(varAndParamMap.get("0result").getStr())){
                    throw new SemanticAnalysisException("Ret-type of fuction and type of expression '" + expr.toString() + "' do not match: " + varAndParamMap.get("0result").getStr() + ", " + expr_type.getStr(), expr);
                }
            }
        }

        @Override
        public void execute(Map<String, FunctionDecl> funcMap, Map<String, Value> varAndParamMap) throws ReturnFromCall, ExecutionException {       
            //change the value of "0result" to return it in NV function
            Value expr_val = expr.evaluate(funcMap, varAndParamMap);
            varAndParamMap.put("0result", expr_val);
        }
}
