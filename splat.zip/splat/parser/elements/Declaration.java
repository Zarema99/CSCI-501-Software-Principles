package splat.parser.elements;

import splat.lexer.Token;

public abstract class Declaration extends ASTElement {
    
        protected Label label;

	public Declaration(Label label, Token tok) {
		super(tok);
                this.label = label;
	}
        
        /**
        * @return the label
        */

        public Label getLabel() {
        return label;
        }
}
