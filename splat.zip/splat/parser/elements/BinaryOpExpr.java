package splat.parser.elements;

import java.util.Map;
import splat.executor.BoolValue;
import splat.executor.ExecutionException;
import splat.executor.IntValue;
import splat.executor.ReturnFromCall;
import splat.executor.StringValue;
import splat.executor.Value;
import splat.lexer.Token;
import splat.semanticanalyzer.SemanticAnalysisException;

public class BinaryOpExpr extends Expression{
    
        //Fields
        private Expression expr1;
        private BinaryOp binary_op;
        private Expression expr2;
    
        public BinaryOpExpr(Expression expr1, BinaryOp binary_op, Expression expr2, Token tok) {
		super(tok);
                this.expr1 = expr1;
                this.binary_op = binary_op;
                this.expr2 = expr2;
	}
        
    /**
     *
     * @return
     */
    @Override
        public String toString() {
                String result = "( " + expr1 + " " + binary_op + " " + expr2 + " ) ";
                return result;
	}

        /**
         * @return the expr1
         */
        public Expression getExpr1() {
            return expr1;
        }

        /**
         * @return the binary_op
         */
        public BinaryOp getBinary_op() {
            return binary_op;
        }

        /**
         * @return the expr2
         */
        public Expression getExpr2() {
            return expr2;
        }

        @Override
        public Type analyzeAndGetType(Map<String, FunctionDecl> funcMap, Map<String, Type> varAndParamMap) throws SemanticAnalysisException{           
            Type expr1_type = expr1.analyzeAndGetType(funcMap, varAndParamMap);
            Type expr2_type = expr2.analyzeAndGetType(funcMap, varAndParamMap);

            if (!expr1_type.getStr().equals(expr2_type.getStr())){
                throw new SemanticAnalysisException("Types of expr1 '" + expr1.toString() + "' and expr2 '" + expr2.toString() + "' do not match: " + expr1_type + ", " + expr2_type, expr2);
                
            }else{
                
                if (binary_op.getStr().equals("and") || binary_op.getStr().equals("or")){
                    
                    if (!expr1_type.getStr().equals("Boolean")){
                        throw new SemanticAnalysisException("Type of expr1 '" + expr1.toString() + "' must be Boolean", expr1);
                    }

                    if (!expr2_type.getStr().equals("Boolean")){
                        throw new SemanticAnalysisException("Type of expr2 '" + expr2.toString() + "' must be Boolean", expr2);
                    }

                    return expr1_type;
                    
                } else if (binary_op.getStr().equals(">") || binary_op.getStr().equals("<") 
                        || binary_op.getStr().equals(">=") || binary_op.getStr().equals("<=")){
                    
                    if (!expr1_type.getStr().equals("Integer")){
                        throw new SemanticAnalysisException("Type of expr1 '" + expr1.toString() + "' must be Integer", expr1);
                    }

                    if (!expr2_type.getStr().equals("Integer")){
                        throw new SemanticAnalysisException("Type of expr2 '" + expr2.toString() + "' must be Integer", expr2);
                    }

                    Type bool = new Type("Boolean", new Token("", -1,-1));
                    return bool;
                    
                }else if (binary_op.getStr().equals("-") || binary_op.getStr().equals("*") || binary_op.getStr().equals("/")
                        || binary_op.getStr().equals("%")){
                    
                    if (!expr1_type.getStr().equals("Integer")){
                        throw new SemanticAnalysisException("Type of expr1 '" + expr1.toString() + "' must be Integer", expr1);
                    }

                    if (!expr2_type.getStr().equals("Integer")){
                        throw new SemanticAnalysisException("Type of expr2 '" + expr2.toString() + "' must be Integer", expr2);
                    }

                    return expr1_type;
                    
                }else if (binary_op.getStr().equals("==")){
                    
                    Type bool = new Type("Boolean", new Token("",-1,-1));
                    return bool;
                    
                }else{ //(binary_op.getStr().equals("+"))
                    
                    if (expr1_type.getStr().equals("Boolean")){
                        throw new SemanticAnalysisException("Type of expr1 '" + expr1.toString() + "' must be Integer or String", expr1);
                    }

                    if (expr2_type.getStr().equals("Boolean")){
                        throw new SemanticAnalysisException("Type of expr2 '" + expr2.toString() + "' must be Integer or String", expr2);
                    }

                    return expr1_type;
                }
            }
        }

        @Override
        public Value evaluate(Map<String, FunctionDecl> funcMap, Map<String, Value> varAndParamMap) throws ExecutionException, ReturnFromCall{            

            Value expr_val1 = expr1.evaluate(funcMap, varAndParamMap);
            Value expr_val2 = expr2.evaluate(funcMap, varAndParamMap);

            if (binary_op.toString().equals("and") || binary_op.toString().equals("or")){

                BoolValue bool_val1 = (BoolValue)expr_val1;
                BoolValue bool_val2 = (BoolValue)expr_val2;
                boolean b;

                if (binary_op.toString().equals("and")){
                    b = bool_val1.isVal() & bool_val2.isVal();
                }else{    //(binary_op.toString().equals("or"))
                    b = bool_val1.isVal() || bool_val2.isVal();
                }

                Value bool_val_new = new BoolValue(b);
                return bool_val_new;

            }else if (binary_op.toString().equals(">") || binary_op.toString().equals("<") || 
                    binary_op.toString().equals(">=") || binary_op.toString().equals("<=")){

                IntValue int_val1 = (IntValue)expr_val1;
                IntValue int_val2 = (IntValue)expr_val2;
                boolean b;

                if (binary_op.toString().equals(">")){
                    b = int_val1.getVal() > int_val2.getVal();
                }else if (binary_op.toString().equals("<")){
                    b = int_val1.getVal() < int_val2.getVal();
                }else if (binary_op.toString().equals(">=")){
                    b = int_val1.getVal() >= int_val2.getVal();
                }else{    //(binary_op.toString().equals("<="))
                    b = int_val1.getVal() <= int_val2.getVal();
                }

                Value bool_val_new = new BoolValue(b);
                return bool_val_new;

            }else if (binary_op.toString().equals("-") || binary_op.toString().equals("*") || 
                    binary_op.toString().equals("/") || binary_op.toString().equals("%")){

                IntValue int_val1 = (IntValue)expr_val1;
                IntValue int_val2 = (IntValue)expr_val2;
                int number;

                if (binary_op.toString().equals("-")){
                    number = int_val1.getVal() - int_val2.getVal();
                }else if (binary_op.toString().equals("*")){
                    number = int_val1.getVal() * int_val2.getVal();
                }else if (binary_op.toString().equals("/")){
                    
                    if (int_val2.getVal() == 0){
                        throw new ExecutionException("Cannot divide by zero! Error at line " 
						+ expr2.getLine() + ", column " + expr2.getColumn(), expr2);
                    }else{
                        number = int_val1.getVal() / int_val2.getVal();
                    }
                    
                }else{    //(binary_op.toString().equals("%")
                    number = int_val1.getVal() % int_val2.getVal();
                }

                Value int_val_new = new IntValue(number);
                return int_val_new;

            }else if (binary_op.toString().equals("==")){
                
                boolean b;
                char ch = expr_val1.toString().charAt(0);

                if (expr_val1.toString().equals("true") || expr_val1.toString().equals("false")){   //Boolean

                    BoolValue bool_val1 = (BoolValue)expr_val1;
                    BoolValue bool_val2 = (BoolValue)expr_val2;

                    b = bool_val1.isVal() == bool_val2.isVal();

                }else if (ch >= 48 & ch <= 57){    //Integer

                    IntValue int_val1 = (IntValue)expr_val1;
                    IntValue int_val2 = (IntValue)expr_val2;

                    b = int_val1.getVal() == int_val2.getVal();

                }else{    //String

                    StringValue str_val1 = (StringValue)expr_val1;
                    StringValue str_val2 = (StringValue)expr_val2;

                    b = str_val1.getVal().equals(str_val2.getVal());
                }

                Value bool_val_new = new BoolValue(b);
                return bool_val_new;
                
            }else{    //(binary_op.toString().equals("+")
                
                char ch = expr_val1.toString().charAt(0);
                int number;
                String str = new String();

                if ((ch >= 48 & ch <= 57) || ch == '-'){    //Integer

                    IntValue int_val1 = (IntValue)expr_val1;
                    IntValue int_val2 = (IntValue)expr_val2;

                    number = int_val1.getVal() + int_val2.getVal();
                    Value int_val_new = new IntValue(number);
                    return int_val_new;

                }else{    //String

                    StringValue str_val1 = (StringValue)expr_val1;
                    StringValue str_val2 = (StringValue)expr_val2;

                    str = str_val1.getVal() + str_val2.getVal();
                    Value str_val_new = new StringValue(str);
                    return str_val_new;
                }
            }
        }   
}
