package splat.parser.elements;

import java.util.Map;
import splat.executor.ExecutionException;
import splat.executor.ReturnFromCall;
import splat.executor.Value;
import splat.lexer.Token;
import splat.semanticanalyzer.SemanticAnalysisException;

public class Assignment extends Statement{
    
        //Fields
        private Label label;
        private Expression expr;
    
        public Assignment(Label label, Expression expr, Token tok) {
		super(tok);
                this.label = label;
                this.expr = expr;
	}
        
    /**
     *
     * @return
     */
    @Override
        public String toString() {
                String result = label + " := " + expr + " ;";
                return result;
	}

        /**
         * @return the label
         */
        public Label getLabel() {
            return label;
        }

        /**
         * @return the expr
         */
        public Expression getExpr() {
            return expr;
        }

        @Override
        public void analyze(Map<String, FunctionDecl> funcMap, Map<String, Type> varAndParamMap) throws SemanticAnalysisException{              
                Type label_type = label.analyzeAndGetType(funcMap, varAndParamMap);
                Type expr_type = expr.analyzeAndGetType(funcMap, varAndParamMap);

                if (!expr_type.getStr().equals(label_type.getStr())){
                    throw new SemanticAnalysisException("Types of expr '" + expr.toString() + "' and label '" + label.getStr() + "' do not match: " + expr_type + ", " + label_type, expr);
                }
        }

        @Override
        public void execute(Map<String, FunctionDecl> funcMap, Map<String, Value> varAndParamMap) throws ReturnFromCall, ExecutionException {         
            Value expr_val = expr.evaluate(funcMap, varAndParamMap);
            varAndParamMap.put(label.getStr(), expr_val);
        }
}
