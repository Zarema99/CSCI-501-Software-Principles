package splat.parser.elements;

import java.util.Map;
import splat.executor.BoolValue;
import splat.executor.ExecutionException;
import splat.executor.IntValue;
import splat.executor.ReturnFromCall;
import splat.executor.Value;
import splat.lexer.Token;
import splat.semanticanalyzer.SemanticAnalysisException;

public class UnaryOpExpr extends Expression{
    
        //Fields
        private UnaryOp unary_op;
        private Expression expr;
    
        public UnaryOpExpr(UnaryOp unary_op, Expression expr, Token tok) {
		super(tok);
                this.unary_op = unary_op;
                this.expr = expr;
	}
        
    /**
     *
     * @return
     */
    @Override
        public String toString() {                
                String result = "( " + unary_op + " " + expr + " )";              
                return result;
	}

        /**
         * @return the unary_op
         */
        public UnaryOp getUnary_op() {
            return unary_op;
        }

        /**
         * @return the expr
         */
        public Expression getExpr() {
            return expr;
        }

        @Override
        public Type analyzeAndGetType(Map<String, FunctionDecl> funcMap, Map<String, Type> varAndParamMap) throws SemanticAnalysisException{         
            Type expr_type = expr.analyzeAndGetType(funcMap, varAndParamMap);

            if (unary_op.toString().equals("not")){
                    if (!expr_type.toString().equals("Boolean")){
                        throw new SemanticAnalysisException("Type of expr '" + expr.toString() + "' must be Boolean", expr);
                    }

                    return expr_type;

            } else{    //(unary_op.toString().equals("-"))

                    if (!expr_type.toString().equals("Integer")){
                        throw new SemanticAnalysisException("Type of expr '" + expr.toString() + "' must be Integer", expr);
                    }
                    
                    return expr_type;
            }
        }

        @Override
        public Value evaluate(Map<String, FunctionDecl> funcMap, Map<String, Value> varAndParamMap) throws ExecutionException, ReturnFromCall {          
            Value expr_val = expr.evaluate(funcMap, varAndParamMap);

            if (unary_op.toString().equals("not")){

                BoolValue bool_val = (BoolValue)expr_val;
                boolean b = !bool_val.isVal();
                Value bool_val_new = new BoolValue(b);
                return bool_val_new;

            }else{

                IntValue int_val = (IntValue)expr_val;
                int number = -int_val.getVal();
                Value int_val_new = new IntValue(number);
                return int_val_new;
            }
        }
}
