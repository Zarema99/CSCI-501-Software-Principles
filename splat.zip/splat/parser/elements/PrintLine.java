package splat.parser.elements;

import java.util.Map;
import splat.executor.ReturnFromCall;
import splat.executor.Value;
import splat.lexer.Token;

public class PrintLine extends Statement{
    
        public PrintLine(Token tok) {
		super(tok);
	}
        
    /**
     *
     * @return
     */
    @Override
        public String toString() {
                String result =  "print_line" + " ;" ;
                return result;
	}

        @Override
        public void analyze(Map<String, FunctionDecl> funcMap, Map<String, Type> varAndParamMap) {
            //nothing to check
        }

        @Override
        public void execute(Map<String, FunctionDecl> funcMap, Map<String, Value> varAndParamMap) throws ReturnFromCall {           
            System.out.println();
        }  
}
