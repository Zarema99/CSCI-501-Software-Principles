package splat.parser.elements;

import splat.lexer.Token;

public class Type extends RetType{
    
        //Fields        
        private String str;
    
        public Type(String str,Token tok) {
		super(tok);
                this.str = str;
	}
        
    /**
     *
     * @return
     */
    @Override
        public String toString() {
                 String result = getStr();
                return result;
	}   

        /**
         * @return the str
         */
        public String getStr() {
            return str;
        } 
}
