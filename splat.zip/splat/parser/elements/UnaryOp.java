package splat.parser.elements;

import splat.lexer.Token;

public class UnaryOp extends ASTElement{
    
        //Fields
        private String str;
    
        public UnaryOp(String str,Token tok) {
		super(tok);
                this.str = str;
	}
        
    /**
     *
     * @return
     */
    @Override
        public String toString() {
                String result = getStr();
                return result;
	}

        /**
         * @return the str
         */
        public String getStr() {
            return str;
        }
}
