package splat.parser.elements;

import java.util.List;
import java.util.Map;
import splat.executor.BoolValue;
import splat.executor.ExecutionException;
import splat.executor.ReturnFromCall;
import splat.executor.Value;

import splat.lexer.Token;
import splat.semanticanalyzer.SemanticAnalysisException;

public class IfThenElse extends Statement{
    
        //Fields
        private Expression expr;
        private List<Statement> stmts1;
        private List<Statement> stmts2;
    
        public IfThenElse(Expression expr, List<Statement> stmts1, List<Statement> stmts2, Token tok) {
		super(tok);
                this.expr = expr;
                this.stmts1 = stmts1;
                this.stmts2 = stmts2;
                
	}
        
    /**
     *
     * @return
     */
    @Override
        public String toString() {
		String result = "if " + expr + " then \n";
		
		for (Statement stmt1 : stmts1) {
			result = result + "      " + stmt1 + "\n";
		}
                
		result = result	+ "   else \n";
                
                for (Statement stmt2 : stmts2) {
			result = result + "      " + stmt2 + "\n";
		}
                
		result = result	+ "   end if ;";
                
		return result;
	}
        
        /**
         * @return the expr
         */
        public Expression getExpr() {
            return expr;
        }

        /**
         * @return the stmts1
         */
        public List<Statement> getStmts1() {
            return stmts1;
        }

        /**
         * @return the stmts2
         */
        public List<Statement> getStmts2() {
            return stmts2;
        }

        @Override
        public void analyze(Map<String, FunctionDecl> funcMap, Map<String, Type> varAndParamMap) throws SemanticAnalysisException {           
            Type expr_type = expr.analyzeAndGetType(funcMap, varAndParamMap);

            if (!expr_type.getStr().equals("Boolean")){
                        throw new SemanticAnalysisException("Type of expr '" + expr.toString() + "' must be Boolean", expr);
            }

            for (Statement stmt1 : getStmts1()) {
                            stmt1.analyze(funcMap, varAndParamMap);
            }

            for (Statement stmt2 : getStmts2()) {
                            stmt2.analyze(funcMap, varAndParamMap);
            }
        }

        @Override
        public void execute(Map<String, FunctionDecl> funcMap, Map<String, Value> varAndParamMap) throws ReturnFromCall, ExecutionException {           
            Value expr_val = expr.evaluate(funcMap, varAndParamMap);
            BoolValue bool_val = (BoolValue)expr_val;

            if (bool_val.isVal()){
                
                for (Statement stmt : getStmts1()) {
                    stmt.execute(funcMap, varAndParamMap);
                }
                
            }else{
                
                for (Statement stmt : getStmts2()) {
                    stmt.execute(funcMap, varAndParamMap);
                }
            }
        } 
}
