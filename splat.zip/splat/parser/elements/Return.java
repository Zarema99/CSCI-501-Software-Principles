package splat.parser.elements;

import java.util.Map;
import splat.executor.BoolValue;
import splat.executor.ReturnFromCall;
import splat.executor.Value;
import splat.lexer.Token;
import splat.semanticanalyzer.SemanticAnalysisException;

public class Return extends Statement{

        public Return(Token tok) {
		super(tok);
	}
        
    /**
     *
     * @return
     */
    @Override
        public String toString() {
                String result =  "return" + " ;" ;
                return result;
	}

        @Override
        public void analyze(Map<String, FunctionDecl> funcMap, Map<String, Type> varAndParamMap) throws SemanticAnalysisException {
            
            if (funcMap.isEmpty()){
                throw new SemanticAnalysisException("Cannot have return in main program;", super.getLine(), super.getColumn());
            }           
        }

        @Override
        public void execute(Map<String, FunctionDecl> funcMap, Map<String, Value> varAndParamMap) throws ReturnFromCall { 
            //change the value of "1result" to indicate that void function is return-terminated
            Value val = varAndParamMap.get("1result") ;
            val = new BoolValue(true);
            varAndParamMap.put("1result", val);
        } 
}
