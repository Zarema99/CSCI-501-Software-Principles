package splat.parser.elements;

import java.util.List;
import java.util.Map;
import java.util.*;
import splat.executor.BoolValue;
import splat.executor.ExecutionException;
import splat.executor.IntValue;
import splat.executor.ReturnFromCall;
import splat.executor.StringValue;
import splat.executor.Value;

import splat.lexer.Token;
import splat.semanticanalyzer.SemanticAnalysisException;

public class FunctStatement extends Statement{
    
        //Fiels
        private Label label;
        private List<Expression> args;
    
        public FunctStatement(Label label, List<Expression> args, Token tok) {
		super(tok);
                this.label = label;
                this.args = args;
	}
        
    /**
     *
     * @return
     */
    @Override
        public String toString() {
                
                String result = label + " ( ";
                int i = 0;
                
                for (Expression expr : args) {
                    
			result = result + expr;
                        
                        if (args.size() > 1 & i != args.size()-1){
                
                            result = result + ", ";
                            i++;
                        }                    
		}
                
		result = result + " ) ;";
                
                return result;
	}
              
        /**
         * @return the label
         */
        public Label getLabel() {
            return label;
        }

        /**
         * @return the args
         */
        public List<Expression> getArgs() {
            return args;
        }

        @Override
        public void analyze(Map<String, FunctionDecl> funcMap, Map<String, Type> varAndParamMap) throws SemanticAnalysisException {
            
            if (funcMap.containsKey(label.toString())){
                
                if(!funcMap.get(label.toString()).getRet_type().toString().equals("void")){
                    throw new SemanticAnalysisException("Ret-type of function '" + funcMap.get(label.toString()).getLabel().getStr() + "' must be void", label);
                }

                int i = 0;
                int j = 0;

                List<Type> params_type = new ArrayList<Type>();
                List<Type> args_type = new ArrayList<Type>();

                //Types and number of parameters
                for (Parameter param: funcMap.get(label.toString()).getParams()){
                    
                        Type param_type = param.getType();
                        params_type.add(param_type); 
                        i++;
                }

                //Types and number of arguments
                for (Expression expr: getArgs()){
                    
                        Type expr_type = expr.analyzeAndGetType(funcMap, varAndParamMap);
                        args_type.add(expr_type);
                        j++;
                }

                if (i!=j){
                    throw new SemanticAnalysisException("Number of parameters and arguments of function '" + funcMap.get(label.toString()).getLabel().getStr() + "' do not match", label);
                }
                
                for(i = 0; i < params_type.size(); i++){
                    
                    if(!params_type.get(i).getStr().equals(args_type.get(i).getStr())){
                        throw new SemanticAnalysisException("Types of parameters and arguments of function '" + funcMap.get(label.toString()).getLabel().getStr() + "' do not match", label);
                    }
                }

            }else{
                throw new SemanticAnalysisException("Function '" + label.getStr() + "' is not declared", label);
            }
        }

        @Override
        public void execute(Map<String, FunctionDecl> funcMap, Map<String, Value> varAndParamMap) throws ReturnFromCall, ExecutionException {
            
            FunctionDecl funcDecl = funcMap.get(label.getStr());

            //set map
            Map<String, Value> varAndParamMap_func = new HashMap<String, Value>();

            //Parameters to the map
            for (Parameter param : funcDecl.getParams()) {

                    String param_label = param.getLabel().toString(); 

                    //Initialize by type (integer - 0, boolean - false, string - empty string)
                    Value val = null;

                    if (param.getType().getStr().equals("Integer")){
                            val = new IntValue(0); 

                    }else if (param.getType().getStr().equals("Boolean")){
                            val = new BoolValue(false); 
                            
                    }else{
                            String str = new String();
                            val = new StringValue(str); 
                    }

                    varAndParamMap_func.put(param_label, val);
            }

            //Local variables to the map
            for (VariableDecl loc_var_decl : funcDecl.getLoc_var_decls()) {

                    String loc_label = loc_var_decl.getLabel().toString(); 
                    
                    //Initialize by type (integer - 0, boolean - false, string - empty string)
                    Value val = null;

                    if (loc_var_decl.getType().getStr().equals("Integer")){
                            val = new IntValue(0); 

                    }else if (loc_var_decl.getType().getStr().equals("Boolean")){
                            val = new BoolValue(false); 
                            
                    }else{
                            String str = new String();
                            val = new StringValue(str); 
                    }
                    
                    varAndParamMap_func.put(loc_label, val);
            }

            List<Value> args_val = new ArrayList<Value>();

            //Values of arguments
            for (Expression expr: getArgs()){
                Value val = expr.evaluate(funcMap, varAndParamMap);
                args_val.add(val);
            }

            //Pass arguments to parameters
            for (Parameter param : funcDecl.getParams()){
                String param_label = param.getLabel().toString(); 
                varAndParamMap_func.put(param_label, args_val.get(0));
                args_val.remove(0);
            }

            //Special label - to find it later
            varAndParamMap_func.put("1result", null);

            for (Statement stmt : funcDecl.getStmts()) {

                if (varAndParamMap_func.get("1result") != null){
                    break;
                }

                stmt.execute(funcMap, varAndParamMap_func);
            }
        }             
}
