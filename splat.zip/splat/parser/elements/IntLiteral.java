package splat.parser.elements;

import java.util.Map;
import splat.executor.IntValue;
import splat.executor.Value;
import splat.lexer.Token;
import splat.semanticanalyzer.SemanticAnalysisException;

public class IntLiteral extends Literal{
    
        //Fields
        private String str;
    
        public IntLiteral(String str, Token tok) {
		super(tok);
                this.str = str;
	}
        
    /**
     *
     * @return
     */
    @Override
        public String toString() {  
                String result = getStr();                
                return result;
	}

        /**
         * @return the str
         */
        public String getStr() {
            return str;
        }

        @Override
        public Type analyzeAndGetType(Map<String, FunctionDecl> funcMap, Map<String, Type> varAndParamMap) throws SemanticAnalysisException {          
            Type integer = new Type("Integer", new Token("", -1,-1));
            return integer;
        }

        @Override
        public Value evaluate(Map<String, FunctionDecl> funcMap, Map<String, Value> varAndParamMap) {
            int number = Integer.parseInt(str);
            Value int_val = new IntValue(number);
            return int_val;
        }
}
