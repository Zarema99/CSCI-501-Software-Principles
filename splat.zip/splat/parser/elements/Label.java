package splat.parser.elements;

import java.util.Map;
import splat.executor.Value;
import splat.lexer.Token;
import splat.semanticanalyzer.SemanticAnalysisException;

public class Label extends Expression {
    
        //Fields
        private String str;
    
        public Label(String str, Token tok) {
		super(tok);
                this.str = str;
	}
        
    /**
     *
     * @return
     */
    @Override
        public String toString() {                
                String result = str;               
                return result;
	}

        /**
         * @return the str
         */
        public String getStr() {
            return str;
        }

        @Override
        public Type analyzeAndGetType(Map<String, FunctionDecl> funcMap, Map<String, Type> varAndParamMap) throws SemanticAnalysisException{           
            if (varAndParamMap.containsKey(str)){
                return varAndParamMap.get(str);
                
            }else{
                throw new SemanticAnalysisException("Variable is not defined '"
                                                    + str + "'", super.getLine(), super.getColumn());
            }
        }

        @Override
        public Value evaluate(Map<String, FunctionDecl> funcMap, Map<String, Value> varAndParamMap) {         
            return varAndParamMap.get(str);
        }   
}
