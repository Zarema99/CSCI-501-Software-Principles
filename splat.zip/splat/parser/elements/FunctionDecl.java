package splat.parser.elements;

import java.util.List;

import splat.lexer.Token;

public class FunctionDecl extends Declaration {

	// Need to add some fields
        private List<Parameter> params;
        private RetType ret_type;
        private List<VariableDecl> loc_var_decls;
        private List<Statement> stmts;
                        
	// Need to add extra arguments for setting fields in the constructor 
	public FunctionDecl(Label label, List<Parameter> params, RetType ret_type, List<VariableDecl> loc_var_decls,
                List<Statement> stmts, Token tok) {
                super(label, tok);

                this.params = params;
                this.ret_type = ret_type;
                this.loc_var_decls = loc_var_decls;
                this.stmts = stmts;		
	}
        	
	// Fix this as well

    /**
     *
     * @return
     */
        @Override
	public String toString() {
       
                String result = super.label + " ( ";
                
		for (Parameter param : params) {
			result = result + param;
		}
                
		result = result + " ) " + ": " + ret_type + " is\n";
                
		for (VariableDecl loc_var_decl : loc_var_decls) {
			result = result + "      " + loc_var_decl + "\n";
		}
                
		result = result + "   begin \n";
                
		for (Statement stmt : stmts) {
			result = result + "      " + stmt + "\n";
		}
                
		result = result	+ "   end;";
		
		return result;
	}

        // Getters?

        /**
         * @return the params
         */
        public List<Parameter> getParams() {
            return params;
        }

        /**
         * @return the ret_type
         */
        public RetType getRet_type() {
            return ret_type;
        }

        /**
         * @return the loc_var_decls
         */
        public List<VariableDecl> getLoc_var_decls() {
            return loc_var_decls;
        }

        /**
         * @return the stmts
         */
        public List<Statement> getStmts() {
            return stmts;
        }
}
