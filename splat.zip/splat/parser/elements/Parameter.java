package splat.parser.elements;

import splat.lexer.Token;

public class Parameter extends ASTElement{
    
        //Fields
        private Label label;
        private Type type;
    
        public Parameter(Label label, Type type, Token tok) {
		super(tok);
                this.label = label;
                this.type = type;
	}
        
    /**
     *
     * @return
     */
    @Override
        public String toString() {
		String result = label + " : " + type;
		return result;
	}

        /**
         * @return the label
         */
        public Label getLabel() {
            return label;
        }

        /**
         * @return the type
         */
        public Type getType() {
            return type;
        }  
}
