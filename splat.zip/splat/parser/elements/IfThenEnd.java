package splat.parser.elements;

import java.util.List;
import java.util.Map;
import splat.executor.BoolValue;
import splat.executor.ExecutionException;
import splat.executor.ReturnFromCall;
import splat.executor.Value;

import splat.lexer.Token;
import splat.semanticanalyzer.SemanticAnalysisException;

public class IfThenEnd extends Statement{
    
        //Fields
        private Expression expr;
        private List<Statement> stmts;
    
        public IfThenEnd(Expression expr, List<Statement> stmts, Token tok) {
		super(tok);
                this.expr = expr;
                this.stmts = stmts;
	}

    /**
     *
     * @return
     */
    @Override
        public String toString() {
		String result = "if " + expr + " then \n";
		
		for (Statement stmt : stmts) {
			result = result + "      " + stmt + "\n";
		}
                
		result = result	+ "   end if ;";

		return result;
	}
   
        /**
         * @return the expr
         */
        public Expression getExpr() {
            return expr;
        }

        /**
         * @return the stmts
         */
        public List<Statement> getStmts() {
            return stmts;
        }

        @Override
        public void analyze(Map<String, FunctionDecl> funcMap, Map<String, Type> varAndParamMap) throws SemanticAnalysisException {            
            Type expr_type = expr.analyzeAndGetType(funcMap, varAndParamMap);

            if (!expr_type.getStr().equals("Boolean")){
                        throw new SemanticAnalysisException("Type of expr '" + expr.toString() + "' must be Boolean", expr);
            }

            for (Statement stmt : getStmts()) {
                            stmt.analyze(funcMap, varAndParamMap);
            }
        }

        @Override
        public void execute(Map<String, FunctionDecl> funcMap, Map<String, Value> varAndParamMap) throws ReturnFromCall, ExecutionException {           
            Value expr_val = expr.evaluate(funcMap, varAndParamMap);
            BoolValue bool_val = (BoolValue)expr_val;

            if (bool_val.isVal()){
                
                for (Statement stmt : getStmts()) {
                    stmt.execute(funcMap, varAndParamMap);
                }
            }
        }
}
