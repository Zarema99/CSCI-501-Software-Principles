package splat.parser.elements;

import splat.lexer.Token;

public abstract class Literal extends Expression{

        public Literal(Token tok) {
		super(tok);
 
	}
}
