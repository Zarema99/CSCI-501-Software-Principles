package splat.parser.elements;

import java.util.Map;
import splat.executor.BoolValue;
import splat.executor.Value;
import splat.lexer.Token;
import splat.semanticanalyzer.SemanticAnalysisException;

public class BoolLiteral extends Literal{
    
        //Fields
        private String str;
    
        public BoolLiteral(String str, Token tok) {
		super(tok);
                this.str = str;
	}
        
    /**
     *
     * @return
     */
    @Override
        public String toString() { 
                String result = getStr();
                return result;
	}

        /**
         * @return the str
         */
        public String getStr() {
            return str;
        }

        @Override
        public Type analyzeAndGetType(Map<String, FunctionDecl> funcMap, Map<String, Type> varAndParamMap) throws SemanticAnalysisException {    
            Type bool = new Type("Boolean", new Token("", -1,-1));
            return bool;
        }

        @Override
        public Value evaluate(Map<String, FunctionDecl> funcMap, Map<String, Value> varAndParamMap) {
            boolean b = Boolean.parseBoolean(str);
            Value bool_val = new BoolValue(b);
            return bool_val;
        }  
}
