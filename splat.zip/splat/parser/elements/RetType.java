package splat.parser.elements;

import splat.lexer.Token;

public class RetType extends ASTElement{

        public RetType(Token tok) {
		super(tok);
	}

    /**
     *
     * @return
     */
    @Override
        public String toString() {
                String result =  "void" ;
                return result;
	}
}
