package splat.parser;

import java.util.ArrayList;
import java.util.List;

import splat.lexer.Token;
import splat.parser.elements.*;

import java.util.*;

public class Parser {

	private List<Token> tokens;
	
	public Parser(List<Token> tokens) {
		this.tokens = tokens;
	}

	/**
	 * Compares the next token to an expected value, and throws
	 * an exception if they don't match.  This removes the front-most
	 * (next) token  
	 * 
	 * @param expected value of the next token
	 * @throws ParseException if the actual token doesn't match what 
	 * 			was expected
	 */
	private void checkNext(String expected) throws ParseException {

		Token tok = tokens.remove(0);
		
		if (!tok.getValue().equals(expected)) {
			throw new ParseException("Expected '"+ expected + "', got '" 
					+ tok.getValue()+ "'.", tok);
		}
	}
	
	/**
	 * Returns a boolean indicating whether or not the next token matches
	 * the expected String value.  This does not remove the token from the
	 * token list.
	 * 
	 * @param expected value of the next token
	 * @return true iff the token value matches the expected string
	 */
	private boolean peekNext(String expected) {
		return tokens.get(0).getValue().equals(expected);
	}
	
	/**
	 * Returns a boolean indicating whether or not the token directly after
	 * the front most token matches the expected String value.  This does 
	 * not remove any tokens from the token list.
	 * 
	 * @param expected value of the token directly after the next token
	 * @return true iff the value matches the expected string
	 */
	private boolean peekTwoAhead(String expected) {
		return tokens.get(1).getValue().equals(expected);
	}
	
	/*
	 *  <program> ::= program <decls> begin <stmts> end ;
	 */
	public ProgramAST parse() throws ParseException {
		
		try {
			// Needed for 'program' token position info
			Token startTok = tokens.get(0);
			
			checkNext("program");
			
			List<Declaration> decls = parseDecls();
			
			checkNext("begin");
			
			List<Statement> stmts = parseStmts();
			
			checkNext("end");
			checkNext(";");
	
			return new ProgramAST(decls, stmts, startTok);
			
		// This might happen if we do a tokens.get(), and nothing is there!
		} catch (IndexOutOfBoundsException ex) {
			
			throw new ParseException("Unexpectedly reached the end of file.", -1, -1);
		}
	}
	
	/*
	 *  <decls> ::= (  <decl>  )*
	 */
	private List<Declaration> parseDecls() throws ParseException {
		
		List<Declaration> decls = new ArrayList<Declaration>();
		
		while (!peekNext("begin")) {
			Declaration decl = parseDecl();
			decls.add(decl);
		}
		
		return decls;
	}
	
	/*
	 * <decl> ::= <var-decl> | <func-decl>
	 */
	private Declaration parseDecl() throws ParseException {

		if (peekTwoAhead(":")) {
			return parseVarDecl();
		} else if (peekTwoAhead("(")) {
			return parseFuncDecl();
		} else {
			Token tok = tokens.get(0);
			throw new ParseException("Declaration expected " + tok, tok);
		}
	}
	
	/*
	 * <func-decl> ::= <label> ( <params> ) : <ret-type> is 
	 * 						<loc-var-decls> begin <stmts> end ;
	 */
	private FunctionDecl parseFuncDecl() throws ParseException {
		// TODO Auto-generated method stub
                
                try {
			Token startTok = tokens.get(0); 
                        Label label = parseLabel();
			checkNext("(");
			List<Parameter> params = parseParams();
			checkNext(")");
                        checkNext(":");
                        RetType ret_type = parseRetType();
                        checkNext("is");
                        List<VariableDecl> loc_var_decls = parseLocVarDecls();                       
                        checkNext("begin");                       
			List<Statement> stmts = parseStmts();			
			checkNext("end");
			checkNext(";");
	
			return new FunctionDecl(label, params, ret_type, loc_var_decls, stmts, startTok);
			
		// This might happen if we do a tokens.get(), and nothing is there!
		} catch (IndexOutOfBoundsException ex) {
			
			throw new ParseException("Unexpectedly reached the end of file.", -1, -1);
		}
	}

	/*
	 * <var-decl> ::= <label> : <type> ;
	 */
	private VariableDecl parseVarDecl() throws ParseException {
		// TODO Auto-generated method stub
                
                try {
			Token startTok = tokens.get(0);			
			Label label = parseLabel();			
			checkNext(":");			
			Type type = parseType();			
			checkNext(";");
                        
			return new VariableDecl(label, type, startTok);
			
		// This might happen if we do a tokens.get(), and nothing is there!
		} catch (IndexOutOfBoundsException ex) {
			
			throw new ParseException("Unexpectedly reached the end of file.", -1, -1);
		}               
	}
        
        /*
	 * <loc-var-decls> ::= ( <var-decl> )*
	 */
        private List<VariableDecl> parseLocVarDecls() throws ParseException {
            
            List<VariableDecl> loc_var_decls = new ArrayList<VariableDecl>();
		
		while (!peekNext("begin")) {
			VariableDecl loc_var_decl = parseVarDecl();
			loc_var_decls.add(loc_var_decl);
		}
		
		return loc_var_decls;
        }
	
	/*
	 * <stmts> ::= (  <stmt>  )*
	 */
	private List<Statement> parseStmts() throws ParseException {
                
                List<Statement> stmts = new ArrayList<Statement>();
		
		while (!peekNext("else") && !peekNext("end")) {
			Statement stmt = parseStmt();
			stmts.add(stmt);
		}
		
		return stmts;
	}
        
        /*
	 * <stmt> ::= <label> := <expr> ; | while <expr> do <stmts> end while ; |
         *            if <expr> then <stmts> else <stmts> end if ; |
         *            if <expr> then <stmts> end if ; |
         *            <label> ( <args> ) ; | print <expr> ; |
         *            print_line ; | return <expr> ; | return ;        
	 */
        private Statement parseStmt() throws ParseException {
            
            if (peekTwoAhead(":=")) {
                    return parseAssignment();
                    
            } else if (peekNext("while")) {
                    return parseWhileLoop();
                    
            } else if (peekNext("if")) {
                
                    //2 options
                    int i;
                    
                    for (i = 0; i < tokens.size(); i++){
                        if (tokens.get(i).getValue().equals("else") || tokens.get(i).getValue().equals("end") ){
                            break;
                        }
                    }
                                                          
                    if(tokens.get(i).getValue().equals("end")){
                            return parseIfThenEnd();
                    }else {
                            return parseIfThenElse();
                    }
                               
            } else if (peekNext("print")) {
                    return parsePrint();
                    
            } else if (peekNext("print_line")) {
                    return parsePrintLine();
                    
            } else if (peekNext("return")) {
                
                    //2 options
                    if (peekTwoAhead(";")){
                        return parseReturn();
                    }else {
                        return parseReturnSmth();
                    }
                    
            } else if (peekTwoAhead("(")) {
                    return parseFunctStatement();
            }
            
            else {
                    Token tok = tokens.get(0);
                    throw new ParseException("Statement expected " + tok, tok);
            }
        }
        
        private Assignment parseAssignment() throws ParseException {
            
            try {
			Token startTok = tokens.get(0);                       
                        Label label = parseLabel();			
			checkNext(":=");			
			Expression expr = parseExpr();			
			checkNext(";");
	
			return new Assignment(label, expr, startTok);
			
		// This might happen if we do a tokens.get(), and nothing is there!
		} catch (IndexOutOfBoundsException ex) {
			
			throw new ParseException("Unexpectedly reached the end of file.", -1, -1);
		}      
        }
        
        private WhileLoop parseWhileLoop() throws ParseException {
            
            try {
			Token startTok = tokens.get(0);			
			checkNext("while");                        
                        Expression expr = parseExpr();                        
                        checkNext("do");			
			List<Statement> stmts = parseStmts();			
			checkNext("end");
                        checkNext("while");
			checkNext(";");
	
			return new WhileLoop(expr, stmts, startTok);
			
		// This might happen if we do a tokens.get(), and nothing is there!
		} catch (IndexOutOfBoundsException ex) {
			
			throw new ParseException("Unexpectedly reached the end of file.", -1, -1);
		}
        }
        
        private IfThenElse parseIfThenElse() throws ParseException {
            
            try {
			Token startTok = tokens.get(0);			
			checkNext("if");			
			Expression expr = parseExpr();			
			checkNext("then");			
			List<Statement> stmts1 = parseStmts();                        
                        checkNext("else");                        
                        List<Statement> stmts2 = parseStmts();			
			checkNext("end");
                        checkNext("if");
			checkNext(";");
	
			return new IfThenElse(expr, stmts1, stmts2, startTok);
			
		// This might happen if we do a tokens.get(), and nothing is there!
		} catch (IndexOutOfBoundsException ex) {
			
			throw new ParseException("Unexpectedly reached the end of file.", -1, -1);
		}
        }
        
        private IfThenEnd parseIfThenEnd() throws ParseException {
            
            try {
			Token startTok = tokens.get(0);			
			checkNext("if");			
			Expression expr = parseExpr();			
			checkNext("then");			
			List<Statement> stmts = parseStmts();
			checkNext("end");
                        checkNext("if");
			checkNext(";");
	
			return new IfThenEnd(expr, stmts, startTok);
			
		// This might happen if we do a tokens.get(), and nothing is there!
		} catch (IndexOutOfBoundsException ex) {
			
			throw new ParseException("Unexpectedly reached the end of file.", -1, -1);
		}
        }
        
        private FunctStatement parseFunctStatement() throws ParseException {
            
            try {
			Token startTok = tokens.get(0);                        
                        Label label = parseLabel();			
			checkNext("(");			
			List<Expression> args = parseArgs();			
			checkNext(")");			
			checkNext(";");
	
			return new FunctStatement(label, args, startTok);
			
		// This might happen if we do a tokens.get(), and nothing is there!
		} catch (IndexOutOfBoundsException ex) {
			
			throw new ParseException("Unexpectedly reached the end of file.", -1, -1);
		}
        }
        
        private Print parsePrint() throws ParseException {
            
            try {
			Token startTok = tokens.get(0);			
			checkNext("print");			
			Expression expr = parseExpr();			
			checkNext(";");
	
			return new Print(expr, startTok);
			
		// This might happen if we do a tokens.get(), and nothing is there!
		} catch (IndexOutOfBoundsException ex) {
			
			throw new ParseException("Unexpectedly reached the end of file.", -1, -1);
		}
        }
        
        private PrintLine parsePrintLine() throws ParseException {
            
            try {
			Token startTok = tokens.get(0);			
			checkNext("print_line");			
			checkNext(";");
                        
			return new PrintLine(startTok);
			
		// This might happen if we do a tokens.get(), and nothing is there!
		} catch (IndexOutOfBoundsException ex) {
			
			throw new ParseException("Unexpectedly reached the end of file.", -1, -1);
		}
        }
        
        private Return parseReturn() throws ParseException {
            
            try {
			Token startTok = tokens.get(0);			
			checkNext("return");			
			checkNext(";");
                        
			return new Return(startTok);
			
		// This might happen if we do a tokens.get(), and nothing is there!
		} catch (IndexOutOfBoundsException ex) {
			
			throw new ParseException("Unexpectedly reached the end of file.", -1, -1);
		}
        }
        
        private ReturnSmth parseReturnSmth() throws ParseException {
            
            try {
			Token startTok = tokens.get(0);			
			checkNext("return");			
			Expression expr = parseExpr();			
			checkNext(";");
			
			return new ReturnSmth(expr, startTok);
			
		// This might happen if we do a tokens.get(), and nothing is there!
		} catch (IndexOutOfBoundsException ex) {
			
			throw new ParseException("Unexpectedly reached the end of file.", -1, -1);
		}
        }
        
        /*
	 * <params> ::= <param> ( , <param> )* | ɛ
	 */
        private List<Parameter> parseParams() throws ParseException {
            
            List<Parameter> params = new ArrayList<Parameter>();
		
		while (!peekNext(")")) {
			Parameter param = parseParam();
			params.add(param);
                        
                        if (!peekNext(")")){
                            checkNext(",");
                        }
		}
		
		return params;
        }
          
        /*
	 * <param> ::= <label> : <type>
	 */
        private Parameter parseParam() throws ParseException {
            
            try {
			Token startTok = tokens.get(0);			
			Label label = parseLabel();			
			checkNext(":");			
			Type type = parseType();
	
			return new Parameter(label, type, startTok);
			
		// This might happen if we do a tokens.get(), and nothing is there!
		} catch (IndexOutOfBoundsException ex) {
			
			throw new ParseException("Unexpectedly reached the end of file.", -1, -1);
		}
        }
             
        /*
	 * <expr> ::= ( <expr> <bin-op> <expr> ) |
         *( <unary-op> <expr> ) |
         *<label> ( <args> ) |
         *<label> | <literal>     
	 */
        private Expression parseExpr() throws ParseException {
            
            char ch = tokens.get(0).getValue().charAt(0);
            
            if (peekNext("(") & (peekTwoAhead("not") || peekTwoAhead("-"))) {
                    return parseUnaryOpExpr();             
                    
            }else if (peekNext("(") & tokens.get(2).getValue().equals(")") == false) {
                    return parseBinaryOpExpr();
                    
            }else if (((ch>=65 & ch<=90) || (ch>=97 & ch<=122) || ch == '_') & peekTwoAhead("(")) {
                    return parseNVFunctCall();
           
            }else if(peekNext("true") || peekNext("false") || ch == '"' || (ch>=48 & ch<=57)){
                    return parseLiteral();
            
            }else if((ch>=65 & ch<=90) || (ch>=97 & ch<=122) || ch == '_'){
                    return parseLabel();
               
            }else {
                    Token tok = tokens.get(0);
                    throw new ParseException("Expression expected " + tok, tok);
            }
        }
        
        private BinaryOpExpr parseBinaryOpExpr() throws ParseException {
            
            try {
			Token startTok = tokens.get(0);			
			checkNext("(");			
			Expression expr1 = parseExpr();                        
                        BinaryOp binary_op = parseBinaryOp();                        
                        Expression expr2 = parseExpr();			
			checkNext(")");
	
			return new BinaryOpExpr(expr1, binary_op, expr2, startTok);
			
		// This might happen if we do a tokens.get(), and nothing is there!
		} catch (IndexOutOfBoundsException ex) {
			
			throw new ParseException("Unexpectedly reached the end of file.", -1, -1);
		}
        }
        
        private UnaryOpExpr parseUnaryOpExpr() throws ParseException {
            
            try {
			Token startTok = tokens.get(0);			
			checkNext("(");                        
                        UnaryOp unary_op = parseUnaryOp();			
			Expression expr = parseExpr();			
			checkNext(")");
	
			return new UnaryOpExpr(unary_op, expr, startTok);
			
		// This might happen if we do a tokens.get(), and nothing is there!
		} catch (IndexOutOfBoundsException ex) {
			
			throw new ParseException("Unexpectedly reached the end of file.", -1, -1);
		}
        }
        
        private NVFunctCall parseNVFunctCall() throws ParseException {
            
            try {
			Token startTok = tokens.get(0);                        
                        Label label = parseLabel();			
			checkNext("(");			
			List<Expression> args = parseArgs();			
			checkNext(")");
				
			return new NVFunctCall(label, args, startTok);
			
		// This might happen if we do a tokens.get(), and nothing is there!
		} catch (IndexOutOfBoundsException ex) {
			
			throw new ParseException("Unexpectedly reached the end of file.", -1, -1);
		}
        }
        
        
        /*
	 * <bin-op> ::= and | or | > | < | == | >= | <= | + | - | * | / | %   
	 */
        private BinaryOp parseBinaryOp() throws ParseException{
            
            try{
                if (peekNext("and") || peekNext("or") || peekNext(">") || peekNext("<") || peekNext("==")
                        || peekNext(">=") || peekNext("<=") || peekNext("+") || peekNext("-") 
                        || peekNext("*") || peekNext("/") || peekNext("%")){
                    
                        Token startTok = tokens.remove(0);
                        
                        return new BinaryOp(startTok.getValue(),startTok);
                        
                }else {
                    Token tok = tokens.get(0);
                    throw new ParseException("BinaryOp expected " + tok, tok);
    
                }
            // This might happen if we do a tokens.get(), and nothing is there!
            }catch(IndexOutOfBoundsException ex) {
			
                    throw new ParseException("Unexpectedly reached the end of file.", -1, -1);
            }
        }
        
        
        /*
	 * <unary-op> ::= not | -  
	 */
        private UnaryOp parseUnaryOp() throws ParseException {
            
            try{                   
                    Token startTok = tokens.remove(0);
                        
                    return new UnaryOp(startTok.getValue(), startTok);
                                        
            // This might happen if we do a tokens.get(), and nothing is there!
            }catch(IndexOutOfBoundsException ex) {
			
                    throw new ParseException("Unexpectedly reached the end of file.", -1, -1);
            }    
        }
        
        /*
	 * <args> ::= <expr> ( , <expr> )* | ɛ
	 */
        private List<Expression> parseArgs() throws ParseException {
            
            List<Expression> args = new ArrayList<Expression>();
		
		while (!peekNext(")")) {
			Expression expr = parseExpr();
			args.add(expr);
                        
                        if (!peekNext(")")){
                            checkNext(",");
                        }
		}
		
		return args;
        }
        
        /*
	 * <label> ::= …sequence of alphanumeric characters and underscore, not starting with a digit...
	 */
        private Label parseLabel() throws ParseException {
            
            try{
                char ch = tokens.get(0).getValue().charAt(0);
                String str = tokens.get(0).getValue();    
            
                //Label cannot be the same as keywords
                List<String> keywords = Arrays.asList("program", "begin", "end", "is", "while", "do", "if", "then", "else", 
                        "print", "print_line", "return", "and", "or", "not", "void", "Integer", "Boolean", "String", "true", "false");
                
                boolean containsStr = keywords.contains(str);
                
                if (((ch >= 65 & ch <= 90) || (ch >= 97 & ch <= 122) || ch == '_') & containsStr == false){
                    
                        Token startTok = tokens.remove(0);
                        
                        return new Label(startTok.getValue(),startTok);
                        
                }else {
                    
                    Token tok = tokens.get(0);
                    throw new ParseException("Label expected " + tok, tok);
                }
            // This might happen if we do a tokens.get(), and nothing is there!
            }catch(IndexOutOfBoundsException ex) {
			
                    throw new ParseException("Unexpectedly reached the end of file.", -1, -1);
            }  
        }
               
        /*
	 * <ret-type> ::= <type> | void
	 */
        private RetType parseRetType() throws ParseException {
            
            try{
                if (peekNext("void")) {

                       Token startTok = tokens.get(0);			
                       checkNext("void");

                       return new RetType(startTok);

               } else if (peekNext("Integer") || peekNext("Boolean") || peekNext("String")){
                       return parseType();

               }else{
                       Token tok = tokens.get(0);
                       throw new ParseException("Ret-type expected " + tok, tok);

               }
            // This might happen if we do a tokens.get(), and nothing is there!
            }catch(IndexOutOfBoundsException ex) {
			
                    throw new ParseException("Unexpectedly reached the end of file.", -1, -1);
            }  
        }
        
        /*
	 * <type> ::= Integer | Boolean | String
	 */
        private Type parseType() throws ParseException {
            
            try{
                if (peekNext("Integer") || peekNext("Boolean") || peekNext("String")){
                        Token startTok = tokens.remove(0);
                        
                        return new Type(startTok.getValue(),startTok);
                        
                }else {                    
                    Token tok = tokens.get(0);
                    throw new ParseException("Type expected " + tok, tok);
                }
            // This might happen if we do a tokens.get(), and nothing is there!
            }catch(IndexOutOfBoundsException ex) {
			
                    throw new ParseException("Unexpectedly reached the end of file.", -1, -1);
            }  
        }
        
        /*
	 * <literal> ::= <int-literal> | <bool-literal> | <string-literal>
	 */
        private Literal parseLiteral() throws ParseException {
            
            try{
                char ch = tokens.get(0).getValue().charAt(0);

                if (peekNext("true") || peekNext("false")) {
                        return parseBoolLiteral();

                } else if (ch == '"') {
                        return parseStringLiteral();

                } else if (ch >= 48 & ch <= 57) {
                        return parseIntLiteral();

                } else {
                        Token tok = tokens.get(0);
                        throw new ParseException("Literal expected " + tok, tok);
                }
            // This might happen if we do a tokens.get(), and nothing is there!
            }catch(IndexOutOfBoundsException ex) {
			
                    throw new ParseException("Unexpectedly reached the end of file.", -1, -1);
            }  
        }
    
        /*
	 * <int-literal> ::= …sequence of decimal digits...
	 */
        private IntLiteral parseIntLiteral() throws ParseException {
            
            try{
                    Token startTok = tokens.remove(0);
                        
                    return new IntLiteral(startTok.getValue(), startTok);
                    
            // This might happen if we do a tokens.get(), and nothing is there!
            }catch(IndexOutOfBoundsException ex) {
			
                    throw new ParseException("Unexpectedly reached the end of file.", -1, -1);
            }  
        }
                 
        /*
	 * <bool-literal> ::= true | false
	 */
        private BoolLiteral parseBoolLiteral() throws ParseException {
            
            try{           
                    Token startTok = tokens.remove(0);
                        
                    return new BoolLiteral(startTok.getValue(), startTok);
                        
            // This might happen if we do a tokens.get(), and nothing is there!
            }catch(IndexOutOfBoundsException ex) {
			
                    throw new ParseException("Unexpectedly reached the end of file.", -1, -1);
            }  
        }        

        /*
	 * <string-literal> ::= "…sequence of non-double-quote, non-backslash displayable characters and spaces... "
	 */
        private StringLiteral parseStringLiteral() throws ParseException {
            
            try{
                    Token startTok = tokens.remove(0);
                        
                    return new StringLiteral(startTok.getValue(), startTok);
                        
            // This might happen if we do a tokens.get(), and nothing is there!
            }catch(IndexOutOfBoundsException ex) {
			
                    throw new ParseException("Unexpectedly reached the end of file.", -1, -1);
            }  
        }
}
